from odoo import api, SUPERUSER_ID


def uninstall_hook(cr, registry):
    env = api.Environment(cr, SUPERUSER_ID, {})

    # Eliminar registros específicos del módulo
    # Eliminar datos relacionados del modelo `ir.actions.server`
    env['ir.actions.server'].search([
        ('model_id.model', '=', 'worker_activity_self_monitoring.TrayIcon')
    ]).unlink()

    # Eliminar cualquier vista personalizada o configuraciones específicas del módulo
    env['ir.ui.view'].search([
        ('key', 'like', 'worker_activity_self_monitoring.%')
    ]).unlink()

    # Eliminar datos relacionados de `ir.config_parameter` si existen configuraciones guardadas
    env['ir.config_parameter'].search([
        ('key', 'like', 'worker_activity_self_monitoring.%')
    ]).unlink()

    # Eliminar datos relacionados de `ir.model.data` para vistas y acciones XML
    env['ir.model.data'].search([
        ('module', '=', 'worker_activity_self_monitoring')
    ]).unlink()

    # Eliminar datos relacionados de `ir.cron` si tienes tareas programadas específicas del módulo
    env['ir.cron'].search([
        ('name', 'like', 'worker_activity_self_monitoring.%')
    ]).unlink()

    # Mensaje de consola para confirmar la limpieza
    print("Worker Activity Self Monitoring module uninstalled and cleaned up successfully.")
